package bgu.spl.mics.application.messages;

import bgu.spl.mics.Event;

/**
 * This type of event send to LandoMicroservice so he could bomb the star destroyer of the empire
 */
public class BombDestroyerEvent implements Event <Boolean>  {

}
