package bgu.spl.mics.application.messages;

import bgu.spl.mics.Event;

/**
 * This event send to R2D2Microservice so he could deactivate the shield generator.
 */
public class DeactivationEvent implements Event <Boolean> {


}
