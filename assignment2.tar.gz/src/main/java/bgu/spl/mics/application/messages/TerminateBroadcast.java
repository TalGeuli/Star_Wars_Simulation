package bgu.spl.mics.application.messages;
import bgu.spl.mics.Broadcast;

/**
 * This broadcast send when a Microservice need to be terminate.
 */
public class TerminateBroadcast implements Broadcast{

}
